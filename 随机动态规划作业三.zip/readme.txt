1. Multi-Echelon Inventory Problem.py 文件用于验证Clark and Scarf （1960）中的策略结构。
2. Policy Structure1.png和Policy Structure2.png图示了两种参数设置下的策略结构，两图横轴均为Echelon 3 Inventory Level。
3. independent of inventory level.png解释了Echelon base-stock level与第三级仓库的实际库存无关。具体参数请见Multi-Echelon Inventory Problem.py中注释部分。
4. Curse of Dimensionality.py文件用于验证维数灾难.
5. Curse of Dimensionality.png显示随着周期数T的增加，程序的cycle time随指数增加。